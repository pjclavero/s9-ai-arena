# S9 AI Arena — Parte 2

Prototipo acumulativo de arena 2D autoritativa para bots programables.

## Incluye

- Motor TypeScript con Rapier 2D.
- Movimiento físico y colisiones de tanques.
- Mapas JSON versionados y validados.
- Muros sólidos.
- Obstáculos destructibles con puntos de vida.
- Spawns por equipo.
- Proyectiles con detección continua mediante raycast.
- Daño, eliminación y ganador.
- Métricas básicas de partida.
- Repetición JSON con mapa, semilla, comandos y eventos.
- Visor Phaser actualizado.
- Dos bots independientes.
- Despliegue completo con Docker Compose.

## Arranque

1. Copiar el contenido en el repositorio.
2. Crear el directorio `data/replays` si no existe.
3. Levantar el proyecto con Docker Compose.
4. Abrir el puerto 3000 para el visor y 8081 para el motor durante desarrollo.

## Archivos principales

- `maps/training-yard.json`: primer mapa.
- `packages/map-schema`: contrato de mapas.
- `packages/protocol`: protocolo versión 2.
- `apps/arena-server`: motor autoritativo.
- `apps/arena-viewer`: visor web.
- `data/replays`: repeticiones generadas.

## Criterios de aceptación

- Los tanques no atraviesan muros.
- Los proyectiles chocan con muros, obstáculos o enemigos.
- Los obstáculos destructibles desaparecen al llegar a cero de vida.
- La partida declara ganador o empate por tiempo.
- Al terminar se guarda una repetición JSON.
- El visor muestra mapa, salud, métricas y resultado.
