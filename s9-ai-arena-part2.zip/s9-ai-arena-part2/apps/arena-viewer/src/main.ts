import Phaser from "phaser";
import type { ArenaSnapshot } from "@s9/protocol";
import "./style.css";

const wsUrl = import.meta.env.VITE_ARENA_WS_URL || `ws://${location.hostname}:8081/viewer`;
const status = document.querySelector<HTMLSpanElement>("#status")!;
let latest: ArenaSnapshot | undefined;
const socket = new WebSocket(wsUrl);
socket.addEventListener("open", () => (status.textContent = "Conectado"));
socket.addEventListener("close", () => (status.textContent = "Desconectado"));
socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data) as ArenaSnapshot;
  if (message.type === "snapshot") latest = message;
});

class ArenaScene extends Phaser.Scene {
  private graphics!: Phaser.GameObjects.Graphics;
  private labels = new Map<string, Phaser.GameObjects.Text>();
  private hud!: Phaser.GameObjects.Text;

  create(): void {
    this.graphics = this.add.graphics();
    this.hud = this.add.text(16, 16, "", { fontFamily: "monospace", fontSize: "14px", color: "#ffffff", backgroundColor: "#00000099", padding: { x: 10, y: 8 } }).setDepth(20);
  }

  update(): void {
    if (!latest) return;
    const scale = Math.min(this.scale.width / latest.arena.width, this.scale.height / latest.arena.height);
    const ox = (this.scale.width - latest.arena.width * scale) / 2;
    const oy = (this.scale.height - latest.arena.height * scale) / 2;
    this.graphics.clear();
    this.graphics.fillStyle(0x151b24, 1);
    this.graphics.fillRect(ox, oy, latest.arena.width * scale, latest.arena.height * scale);

    for (const body of latest.bodies) {
      const x = ox + body.x * scale;
      const y = oy + body.y * scale;
      this.graphics.save();
      this.graphics.translateCanvas(x, y);
      this.graphics.rotateCanvas(body.rotation);
      this.graphics.fillStyle(body.kind === "wall" ? 0x59636f : 0xa86f32, 1);
      this.graphics.fillRect(-body.width * scale / 2, -body.height * scale / 2, body.width * scale, body.height * scale);
      this.graphics.restore();
      if (body.kind === "destructible" && body.health !== undefined && body.maxHealth) {
        this.graphics.fillStyle(0x1f252d, 1);
        this.graphics.fillRect(x - 30 * scale, y - body.height * scale / 2 - 10, 60 * scale, 5);
        this.graphics.fillStyle(0xf4a261, 1);
        this.graphics.fillRect(x - 30 * scale, y - body.height * scale / 2 - 10, 60 * scale * body.health / body.maxHealth, 5);
      }
    }

    for (const projectile of latest.projectiles) {
      this.graphics.fillStyle(0xffd166, 1);
      this.graphics.fillCircle(ox + projectile.x * scale, oy + projectile.y * scale, Math.max(2, 4 * scale));
    }

    const liveIds = new Set<string>();
    for (const tank of latest.tanks) {
      liveIds.add(tank.id);
      const x = ox + tank.x * scale;
      const y = oy + tank.y * scale;
      const color = tank.team === "red" ? 0xef476f : 0x118ab2;
      this.graphics.save();
      this.graphics.translateCanvas(x, y);
      this.graphics.rotateCanvas(tank.heading);
      this.graphics.fillStyle(color, tank.health > 0 ? 1 : 0.25);
      this.graphics.fillRoundedRect(-24 * scale, -18 * scale, 48 * scale, 36 * scale, 7 * scale);
      this.graphics.restore();
      this.graphics.lineStyle(Math.max(2, 5 * scale), 0xf5f7fa, 1);
      this.graphics.lineBetween(x, y, x + Math.cos(tank.turretHeading) * 38 * scale, y + Math.sin(tank.turretHeading) * 38 * scale);
      this.graphics.fillStyle(0x222831, 1);
      this.graphics.fillRect(x - 25 * scale, y - 34 * scale, 50 * scale, 6 * scale);
      this.graphics.fillStyle(0x06d6a0, 1);
      this.graphics.fillRect(x - 25 * scale, y - 34 * scale, 50 * scale * tank.health / 100, 6 * scale);
      let label = this.labels.get(tank.id);
      if (!label) {
        label = this.add.text(0, 0, "", { fontFamily: "Arial", fontSize: "14px", color: "#ffffff" }).setOrigin(0.5, 1);
        this.labels.set(tank.id, label);
      }
      label.setText(`${tank.name} · ${tank.health}`);
      label.setPosition(x, y - 40 * scale);
    }
    for (const [id, label] of this.labels) if (!liveIds.has(id)) { label.destroy(); this.labels.delete(id); }
    this.hud.setText([
      `${latest.arena.mapName} · seed ${latest.arena.seed}`,
      `Tick ${latest.tick} · disparos ${latest.metrics.shots} · impactos ${latest.metrics.hits}`,
      `Daño ${latest.metrics.damage} · obstáculos destruidos ${latest.metrics.destroyedObstacles}`,
      latest.winner ? `GANADOR: ${latest.winner.toUpperCase()}` : "Partida en curso"
    ]);
  }
}

new Phaser.Game({
  type: Phaser.AUTO,
  parent: "game",
  backgroundColor: "#10141c",
  scale: { mode: Phaser.Scale.RESIZE, width: "100%", height: "100%" },
  scene: ArenaScene,
});
