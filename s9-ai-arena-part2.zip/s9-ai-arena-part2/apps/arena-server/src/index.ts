import { createServer } from "node:http";
import { randomUUID } from "node:crypto";
import { readFile, mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import RAPIER from "@dimforge/rapier2d-compat";
import { WebSocketServer, WebSocket } from "ws";
import { validateArenaMap, type ArenaMap } from "@s9/map-schema";
import { PROTOCOL_VERSION, type ArenaSnapshot, type BotCommand, type BotObservation, type BotRegistration, type MatchMetrics, type StaticBodySnapshot, type TankSnapshot, type TeamId } from "@s9/protocol";

await RAPIER.init();
const port = Number(process.env.ARENA_PORT ?? 8081);
const tickRate = Number(process.env.TICK_RATE ?? 30);
const mapPath = process.env.MAP_PATH ?? "/app/maps/training-yard.json";
const replayDir = process.env.REPLAY_DIR ?? "/app/data/replays";
const maxMatchTicks = Number(process.env.MAX_MATCH_TICKS ?? tickRate * 180);
const arenaMap = validateArenaMap(JSON.parse(await readFile(mapPath, "utf8")));
const world = new RAPIER.World({ x: 0, y: 0 });
const tankHalf = { x: 24, y: 18 };
const matchId = randomUUID();

interface TankState extends TankSnapshot { socket: WebSocket; body: RAPIER.RigidBody; throttle: number; turn: number; turretTurn: number; wantsFire: boolean; cooldown: number; }
interface ProjectileState { id: string; ownerId: string; team: TeamId; body: RAPIER.RigidBody; ttl: number; }
interface ObstacleState { id: string; body: RAPIER.RigidBody; collider: RAPIER.Collider; health: number; maxHealth: number; width: number; height: number; rotation: number; }
interface ReplayFrame { tick: number; commands: Record<string, BotCommand>; events: Array<Record<string, unknown>>; }

const tanks = new Map<string, TankState>();
const viewers = new Set<WebSocket>();
const projectiles: ProjectileState[] = [];
const obstacles = new Map<string, ObstacleState>();
const staticBodies: StaticBodySnapshot[] = [];
const replayFrames: ReplayFrame[] = [];
const pendingCommands: Record<string, BotCommand> = {};
const metrics: MatchMetrics = { shots: 0, hits: 0, damage: 0, destroyedObstacles: 0, elapsedTicks: 0 };
let tick = 0;
let winner: TeamId | "draw" | undefined;
let replaySaved = false;

function createFixedRect(id: string, kind: "wall" | "destructible", x: number, y: number, width: number, height: number, rotation = 0, health?: number): void {
  const body = world.createRigidBody(RAPIER.RigidBodyDesc.fixed().setTranslation(x, y).setRotation(rotation));
  const collider = world.createCollider(RAPIER.ColliderDesc.cuboid(width / 2, height / 2).setRestitution(0), body);
  staticBodies.push({ id, kind, x, y, width, height, rotation, health, maxHealth: health });
  if (kind === "destructible" && health) obstacles.set(id, { id, body, collider, health, maxHealth: health, width, height, rotation });
}
for (const wall of arenaMap.walls) createFixedRect(wall.id, "wall", wall.x, wall.y, wall.width, wall.height, wall.rotation ?? 0);
for (const obstacle of arenaMap.obstacles) createFixedRect(obstacle.id, "destructible", obstacle.x, obstacle.y, obstacle.width, obstacle.height, obstacle.rotation ?? 0, obstacle.health);

const httpServer = createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ status: "ok", matchId, tick, bots: tanks.size, map: arenaMap.id, winner }));
    return;
  }
  if (req.url === "/snapshot") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify(buildSnapshot()));
    return;
  }
  res.writeHead(404).end();
});
const wss = new WebSocketServer({ noServer: true });
httpServer.on("upgrade", (request, socket, head) => {
  const pathname = new URL(request.url ?? "/", `http://${request.headers.host}`).pathname;
  if (pathname !== "/bot" && pathname !== "/viewer") return socket.destroy();
  wss.handleUpgrade(request, socket, head, (ws) => wss.emit("connection", ws, request, pathname));
});

wss.on("connection", (socket: WebSocket, _request, pathname: string) => {
  if (pathname === "/viewer") {
    viewers.add(socket);
    socket.on("close", () => viewers.delete(socket));
    socket.send(JSON.stringify(buildSnapshot()));
    return;
  }
  let botId: string | undefined;
  socket.on("message", (raw) => {
    let message: unknown;
    try { message = JSON.parse(raw.toString()); } catch { return socket.close(1003, "Invalid JSON"); }
    if (!botId) {
      const reg = message as Partial<BotRegistration>;
      if (reg.type !== "register" || reg.protocolVersion !== PROTOCOL_VERSION || !reg.botId || !reg.name || (reg.team !== "red" && reg.team !== "blue") || tanks.has(reg.botId)) return socket.close(1008, "Invalid registration");
      const spawn = arenaMap.spawns.find((item) => item.team === reg.team)!;
      const body = world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(spawn.x, spawn.y).setRotation(spawn.heading).setLinearDamping(6).setAngularDamping(8).lockTranslations());
      body.setEnabledTranslations(true, true, false);
      world.createCollider(RAPIER.ColliderDesc.cuboid(tankHalf.x, tankHalf.y).setDensity(1).setFriction(0.9), body);
      botId = reg.botId;
      tanks.set(botId, { id: botId, name: reg.name, team: reg.team, x: spawn.x, y: spawn.y, heading: spawn.heading, turretHeading: spawn.heading, health: 100, socket, body, throttle: 0, turn: 0, turretTurn: 0, wantsFire: false, cooldown: 0 });
      console.log(`Bot connected: ${reg.name} (${reg.team})`);
      return;
    }
    const command = message as Partial<BotCommand>;
    const tank = tanks.get(botId);
    if (!tank || command.type !== "command" || command.tick !== tick || winner) return;
    const accepted: BotCommand = { type: "command", tick, movement: { throttle: clamp(command.movement?.throttle ?? 0), turn: clamp(command.movement?.turn ?? 0) }, turret: { turn: clamp(command.turret?.turn ?? 0), fire: Boolean(command.turret?.fire) } };
    tank.throttle = accepted.movement.throttle; tank.turn = accepted.movement.turn; tank.turretTurn = accepted.turret.turn; tank.wantsFire = accepted.turret.fire; pendingCommands[botId] = accepted;
  });
  socket.on("close", () => { if (botId) { const tank = tanks.get(botId); if (tank) world.removeRigidBody(tank.body); tanks.delete(botId); } });
});

function clamp(value: number): number { return Number.isFinite(value) ? Math.max(-1, Math.min(1, value)) : 0; }
function normalizeAngle(value: number): number { const tau = Math.PI * 2; return ((value % tau) + tau) % tau; }
function publicTank(tank: TankState): TankSnapshot { const p = tank.body.translation(); return { id: tank.id, name: tank.name, team: tank.team, x: p.x, y: p.y, heading: tank.body.rotation(), turretHeading: tank.turretHeading, health: tank.health }; }
function rayHitProjectile(projectile: ProjectileState, nextX: number, nextY: number): { tank?: TankState; obstacle?: ObstacleState } | undefined {
  const p = projectile.body.translation(); const dx = nextX - p.x; const dy = nextY - p.y; const length = Math.hypot(dx, dy); if (length === 0) return;
  const ray = new RAPIER.Ray({ x: p.x, y: p.y }, { x: dx / length, y: dy / length });
  const hit = world.castRay(ray, length, true, undefined, undefined, undefined, projectile.body);
  if (!hit) return;
  for (const tank of tanks.values()) if (tank.body.handle === hit.collider.parent()?.handle && tank.id !== projectile.ownerId && tank.team !== projectile.team && tank.health > 0) return { tank };
  for (const obstacle of obstacles.values()) if (obstacle.collider.handle === hit.collider.handle) return { obstacle };
  return {};
}
async function saveReplay(): Promise<void> {
  if (replaySaved) return; replaySaved = true; await mkdir(replayDir, { recursive: true });
  await writeFile(path.join(replayDir, `${matchId}.json`), JSON.stringify({ version: 1, matchId, map: arenaMap, tickRate, winner: winner ?? "draw", metrics, frames: replayFrames }, null, 2));
}
function checkWinner(): void {
  const living = [...tanks.values()].filter((tank) => tank.health > 0);
  const teams = new Set(living.map((tank) => tank.team));
  if (tanks.size >= 2 && teams.size === 1) winner = living[0]?.team ?? "draw";
  if (tick >= maxMatchTicks) winner = "draw";
  if (winner) void saveReplay();
}
function update(): void {
  if (!winner) tick += 1;
  metrics.elapsedTicks = tick;
  const dt = 1 / tickRate;
  const events: Array<Record<string, unknown>> = [];
  for (const tank of tanks.values()) {
    if (tank.health <= 0 || winner) { tank.body.setLinvel({ x: 0, y: 0 }, true); tank.body.setAngvel(0, true); continue; }
    const heading = tank.body.rotation(); const speed = tank.throttle * 170;
    tank.body.setLinvel({ x: Math.cos(heading) * speed, y: Math.sin(heading) * speed }, true);
    tank.body.setAngvel(tank.turn * 2.4, true);
    tank.turretHeading = normalizeAngle(tank.turretHeading + tank.turretTurn * 3.5 * dt);
    tank.cooldown = Math.max(0, tank.cooldown - 1);
    if (tank.wantsFire && tank.cooldown === 0) {
      const x = tank.body.translation().x + Math.cos(tank.turretHeading) * 38; const y = tank.body.translation().y + Math.sin(tank.turretHeading) * 38;
      const body = world.createRigidBody(RAPIER.RigidBodyDesc.kinematicVelocityBased().setTranslation(x, y));
      world.createCollider(RAPIER.ColliderDesc.ball(4).setSensor(true), body);
      body.setLinvel({ x: Math.cos(tank.turretHeading) * 480, y: Math.sin(tank.turretHeading) * 480 }, true);
      projectiles.push({ id: randomUUID(), ownerId: tank.id, team: tank.team, body, ttl: tickRate * 3 });
      tank.cooldown = Math.round(tickRate * 0.65); metrics.shots += 1; events.push({ type: "shot", tankId: tank.id });
    }
  }
  world.step();
  for (let i = projectiles.length - 1; i >= 0; i -= 1) {
    const projectile = projectiles[i]; const p = projectile.body.translation(); const v = projectile.body.linvel(); const nextX = p.x + v.x * dt; const nextY = p.y + v.y * dt;
    const collision = rayHitProjectile(projectile, nextX, nextY); projectile.ttl -= 1;
    let remove = projectile.ttl <= 0 || p.x < 0 || p.y < 0 || p.x > arenaMap.width || p.y > arenaMap.height || Boolean(collision);
    if (collision?.tank) { collision.tank.health = Math.max(0, collision.tank.health - 20); metrics.hits += 1; metrics.damage += 20; events.push({ type: "tank-hit", targetId: collision.tank.id, damage: 20 }); }
    if (collision?.obstacle) {
      collision.obstacle.health -= 20; metrics.hits += 1; events.push({ type: "obstacle-hit", obstacleId: collision.obstacle.id, damage: 20 });
      if (collision.obstacle.health <= 0) { world.removeRigidBody(collision.obstacle.body); obstacles.delete(collision.obstacle.id); metrics.destroyedObstacles += 1; events.push({ type: "obstacle-destroyed", obstacleId: collision.obstacle.id }); }
    }
    if (remove) { world.removeRigidBody(projectile.body); projectiles.splice(i, 1); }
  }
  checkWinner();
  replayFrames.push({ tick, commands: { ...pendingCommands }, events });
  for (const key of Object.keys(pendingCommands)) delete pendingCommands[key];
  for (const tank of tanks.values()) if (tank.socket.readyState === WebSocket.OPEN && tank.health > 0 && !winner) {
    const observation: BotObservation = { type: "observation", tick, self: publicTank(tank), visibleEnemies: [...tanks.values()].filter((other) => other.id !== tank.id && other.team !== tank.team && other.health > 0).map(publicTank) };
    tank.socket.send(JSON.stringify(observation));
  }
  const snapshot = JSON.stringify(buildSnapshot()); for (const viewer of viewers) if (viewer.readyState === WebSocket.OPEN) viewer.send(snapshot);
}
function buildSnapshot(): ArenaSnapshot {
  const bodies: StaticBodySnapshot[] = staticBodies.filter((body) => body.kind === "wall" || obstacles.has(body.id)).map((body) => body.kind === "destructible" ? { ...body, health: obstacles.get(body.id)?.health ?? 0 } : body);
  return { type: "snapshot", tick, matchId, arena: { width: arenaMap.width, height: arenaMap.height, mapId: arenaMap.id, mapName: arenaMap.name, seed: arenaMap.seed }, tanks: [...tanks.values()].map(publicTank), projectiles: projectiles.map((item) => ({ id: item.id, ownerId: item.ownerId, ...item.body.translation() })), bodies, metrics: { ...metrics }, winner };
}
setInterval(update, 1000 / tickRate);
httpServer.listen(port, "0.0.0.0", () => console.log(`S9 Arena ${matchId} listening on ${port}; map=${arenaMap.id}; tickRate=${tickRate}`));
