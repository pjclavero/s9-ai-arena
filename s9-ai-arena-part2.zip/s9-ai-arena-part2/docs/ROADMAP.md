# Roadmap

## Completado en parte 2
- Rapier 2D.
- Mapas JSON y esquema versionado.
- Muros y obstáculos destructibles.
- Spawns por equipo.
- Métricas y replay básico.

## Parte 3 propuesta
- Reinicio y gestor de partidas.
- Varios mapas y selector.
- Sensores limitados y línea de visión.
- Sistema inicial de módulos de tanque.
- SDK de bots documentado.
- Pruebas automáticas del motor y mapas.
