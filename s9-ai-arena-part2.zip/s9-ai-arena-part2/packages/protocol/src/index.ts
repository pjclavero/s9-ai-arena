export const PROTOCOL_VERSION = 2 as const;
export type TeamId = "red" | "blue";

export interface BotRegistration { type: "register"; protocolVersion: typeof PROTOCOL_VERSION; botId: string; name: string; team: TeamId; }
export interface BotCommand { type: "command"; tick: number; movement: { throttle: number; turn: number }; turret: { turn: number; fire: boolean }; }
export interface TankSnapshot { id: string; name: string; team: TeamId; x: number; y: number; heading: number; turretHeading: number; health: number; }
export interface ProjectileSnapshot { id: string; ownerId: string; x: number; y: number; }
export interface StaticBodySnapshot { id: string; kind: "wall" | "destructible"; x: number; y: number; width: number; height: number; rotation: number; health?: number; maxHealth?: number; }
export interface MatchMetrics { shots: number; hits: number; damage: number; destroyedObstacles: number; elapsedTicks: number; }
export interface BotObservation { type: "observation"; tick: number; self: TankSnapshot; visibleEnemies: TankSnapshot[]; }
export interface ArenaSnapshot {
  type: "snapshot";
  tick: number;
  matchId: string;
  arena: { width: number; height: number; mapId: string; mapName: string; seed: number };
  tanks: TankSnapshot[];
  projectiles: ProjectileSnapshot[];
  bodies: StaticBodySnapshot[];
  metrics: MatchMetrics;
  winner?: TeamId | "draw";
}
